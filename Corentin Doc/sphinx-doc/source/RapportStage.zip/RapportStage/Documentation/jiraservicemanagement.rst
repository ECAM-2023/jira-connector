Jira service management
=======================


Gestion des clients
-------------------

Création d'une organisation ECAM qui contient un certain nombre de clients. Dans 'Queues', se trouve toutes les requests envoyées par les clients.
Ce qui est important a gérer dans les tickets sont le time traking et l'original estimate. Components seraient les versions, composants, librairies. Pour le time tracking ,
il faut aller dans "Work Log" puis "Log work": cela va directement démander une clock et compter le temps de prestation. On peut aussi directement cliquer sur time tracking.
Dedans on peut marquer le temps presté, choisir la date et faire un Work description (ex: meeting et personne présente).

On peut modifier les SLAs dans les projets settings: Time to resolution, Time to first response.
Automation:
Forms: définir un type de formulaire pour les requests des clients.