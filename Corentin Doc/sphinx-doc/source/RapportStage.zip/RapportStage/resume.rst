Sources
=======

| [GitHub] GitHub : Génération d’une nouvelle clé SSH et ajout de celle-ci à ssh-agent : Une fois que vous avez vérifié les clés SSH existantes, vous pouvez générer une nouvelle clé SSH à utiliser pour l’authentification, puis l’ajouter à l’agent ssh : https://docs.github.com/fr/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent. Consulté le 3 avril 2023.
| [GitHub] GitHub : Generating a new GPG key : If you don't have an existing GPG key, you can generate a new GPG key to use for signing commits and tags. : https://docs.github.com/en/authentication/managing-commit-signature-verification/generating-a-new-gpg-key. Consulté le 3 avril 2023.


.. https://auth.atlassian.com/authorize?audience=api.atlassian.com&client_id=nr3DZPJ129vipN5AwMPBiAk0AZDBIs0I&scope=read%3Ame%20read%3Aaccount&redirect_uri=https%3A%2F%2Foauth.pstmn.io%2Fv1%2Fbrowser-callback&state=${read%3Ame%20read%3Aaccount}&response_type=code&prompt=consent


.. https://auth.atlassian.com/authorize?audience=api.atlassian.com&client_id=nr3DZPJ129vipN5AwMPBiAk0AZDBIs0I&scope=read%3Aservicedesk-request%20manage%3Aservicedesk-customer%20write%3Aservicedesk-request%20read%3Aservicemanagement-insight-objects&redirect_uri=https%3A%2F%2Foauth.pstmn.io%2Fv1%2Fbrowser-callback&state=${}&response_type=code&prompt=consent





.. curl https://atlassian.example.com/rest/oauth2/latest/authorize?client_id=CLIENT_ID&redirect_uri=REDIRECT_URI&response_type=code&state=STATE&scope=SCOPE&code_challenge=CODE_CHALLENGE&code_challenge_method=S256




